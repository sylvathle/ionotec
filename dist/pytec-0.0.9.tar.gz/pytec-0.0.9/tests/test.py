import sys

#print ("sys")
#sys.path.insert(0,'C:\\Users\\User\\Documents\\GitHub\\pytec\\src\\pytec')

#for p in sys.path:
#    print(p)

#from . import pytec
#from ..src.pytec import tec

from pytec import tec

#tec.st.create_output("output")

#sys.exit()

data="C:\\Users\\User\\Documents\\TEC\\data\\"

f_obs=[data+"2022\\285\\antc2850.22o",data+"2022\\286\\antc2860.22o",data+"2022\\287\\antc2870.22o"]
f_nav=[data+"2022\\285\\brdc2850.22n",data+"2022\\286\\brdc2860.22n",data+"2022\\287\\brdc2870.22n"]
f_bias=data+"2022\\285\\P1C12210.DCB"

station_tec = tec.tec(f_obs,f_nav,f_bias)
station_tec.compute_vtec()

from pytec import graph

graph.plot_station(station_tec.df_obs,"output/antc",mozaic=False)
